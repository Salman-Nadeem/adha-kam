const mongoose = require("mongoose");


const userRole_MOdel = mongoose.Schema(

    {

        Name:{
            type:String,
            required:[true," Name must be enter"],
            
        },

        Email:{
            type:String,
            required:[true,"Email must be there"]
        },
        password:{
            type:String,
            required:[true,"status must be there"]
        },
        Role:{
            type:String,
            required:[true,"Roles  must be there"]
        }
        
    }
)  
        

const Useraccount =  mongoose.model("User",userRole_MOdel)
      
module.exports = {Useraccount}




