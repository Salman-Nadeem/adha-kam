const {Useraccount} = require("../Model/useraccount");


// API http://localhost:5000/user

async function getAllUsers(req, res) {
    return res.send("get sucssesfulll")
}



// Import your Useraccount model at the top


async function createrole(req, res) {
    const { Name, Email, password, Role } = req.body;

    const roleNameCheck = /^[a-zA-Z]+(?: [a-zA-Z]+)*$/;

    if (roleNameCheck.test(Name)) {
        // Check if the role already exists
        const exists = await Useraccount.find({ Role: Role });

        if (exists.length > 0) {
            return res.send({ "error": "Role already exists" });
        }

        // Create a new Useraccount entry
        const newUserAccount = await Useraccount.create({
            Name: Name,
            Email: Email,
            password: password,  
            Role: Role,  
        });

        return res.send(newUserAccount);
    } else {
        return res.send({ "error": "Invalid role name format" });
    }
}




    
module.exports = {createrole ,getAllUsers}
